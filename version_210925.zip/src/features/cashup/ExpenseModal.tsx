import { useState } from "react";
import { useCashup } from "./cashupContext";
import { toInt } from "@/utils/currency";

const ExpenseModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { addExpense, withdrawCash, addCashTip } = useCashup();
  const [type, setType] = useState<"expense" | "withdraw" | "tip">("expense");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [concept, setConcept] = useState(""); // ⬅️ nuevo

  const save = () => {
    const val = toInt(amount);
    if (val <= 0) return alert("Monto inválido");
    try {
      if (type === "expense") {
        addExpense({ amount: val, note, concept }); // ⬅️ ahora válido
      } else if (type === "withdraw") {
        withdrawCash(val);
      } else {
        addCashTip(val);
      }
      onClose();
    } catch (e: any) {
      alert(e?.message || "Error");
    }
  };

  return (
    <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-4 w-[380px] border">
        <h3 className="font-bold mb-2">Gasto / Retiro / Propina</h3>

        <div className="space-y-3">
          <select
            className="border rounded w-full px-2 py-1"
            value={type}
            onChange={(e) => setType(e.target.value as any)}
          >
            <option value="expense">Registrar gasto (sale de caja)</option>
            <option value="withdraw">Retiro de efectivo</option>
            <option value="tip">Propina en efectivo</option>
          </select>

          <input
            className="border rounded w-full px-2 py-1"
            placeholder="Monto $"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            inputMode="numeric"
          />

          {type === "expense" && (
            <>
              <input
                className="border rounded w-full px-2 py-1"
                placeholder="Concepto (p. ej., tomates, insumo cocina, delivery)"
                value={concept}
                onChange={(e) => setConcept(e.target.value)}
              />
              <input
                className="border rounded w-full px-2 py-1"
                placeholder="Detalle / nota (opcional)"
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </>
          )}

          <div className="flex justify-end gap-2">
            <button className="px-3 py-1 rounded border" onClick={onClose}>
              Cancelar
            </button>
            <button className="px-3 py-1 rounded bg-emerald-600 text-white" onClick={save}>
              Guardar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default ExpenseModal;
