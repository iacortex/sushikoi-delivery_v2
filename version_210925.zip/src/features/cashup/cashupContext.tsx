import React, { createContext, useContext, useMemo, useState } from "react";

export type PaymentMethod =
  | "EFECTIVO_SISTEMA"
  | "DEBITO_SISTEMA"
  | "CREDITO_SISTEMA"
  | "POS_DEBITO"
  | "POS_CREDITO"
  | "TRANSFERENCIA";

type Expense = {
  id: string;
  amount: number;
  note?: string;
  concept?: string;        // ⬅️ NUEVO
  createdAt: number;
};

type Session = {
  id: string;
  status: "OPEN" | "CLOSED";
  open: { cashierName: string; openingFloat: number; openedAt: number };
  close?: { closedAt: number; signedBy?: string };
  ops: {
    salesRuntime: { byMethod: Partial<Record<PaymentMethod, number>> };
    expenses: Expense[];
    withdrawals: number;
    tips: { cashTips: number };
  };
};

type CashupContextValue = {
  current: Session | null;
  openShift: (cashierName: string, openingFloat: number) => void;
  addSale: (pm: PaymentMethod, amount: number) => void;
  addExpense: (payload: { amount: number; note?: string; concept?: string }) => void; // ⬅️ cambia firma
  withdrawCash: (amount: number) => void;
  addCashTip: (amount: number) => void;
  closeShift: (signedBy?: string) => void;
  listSessions: () => Session[];
};

const Ctx = createContext<CashupContextValue | null>(null);

export const CashupProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sessions, setSessions] = useState<Session[]>([]);
  const current = useMemo(() => sessions.find(s => s.status === "OPEN") ?? null, [sessions]);

  function openShift(cashierName: string, openingFloat: number) {
    if (current) throw new Error("Ya hay un turno abierto");
    setSessions(prev => [
      {
        id: String(Date.now()),
        status: "OPEN",
        open: { cashierName, openingFloat, openedAt: Date.now() },
        ops: {
          salesRuntime: { byMethod: {} },
          expenses: [],
          withdrawals: 0,
          tips: { cashTips: 0 },
        },
      },
      ...prev,
    ]);
  }

  function addSale(pm: PaymentMethod, amount: number) {
    if (!current) throw new Error("No hay turno abierto");
    setSessions(prev =>
      prev.map(s => {
        if (s.id !== current.id) return s;
        const by = { ...(s.ops.salesRuntime.byMethod || {}) };
        by[pm] = (by[pm] || 0) + (amount || 0);
        return { ...s, ops: { ...s.ops, salesRuntime: { byMethod: by } } };
      })
    );
  }

  function addExpense({ amount, note, concept }: { amount: number; note?: string; concept?: string }) {
    if (!current) throw new Error("No hay turno abierto");
    const exp: Expense = {
      id: crypto.randomUUID?.() || String(Math.random()),
      amount,
      note,
      concept,                 // ⬅️ guarda concept
      createdAt: Date.now(),
    };
    setSessions(prev =>
      prev.map(s => (s.id === current.id ? { ...s, ops: { ...s.ops, expenses: [...s.ops.expenses, exp] } } : s))
    );
  }

  function withdrawCash(amount: number) {
    if (!current) throw new Error("No hay turno abierto");
    setSessions(prev => prev.map(s => (s.id === current.id ? { ...s, ops: { ...s.ops, withdrawals: (s.ops.withdrawals || 0) + (amount || 0) } } : s)));
  }

  function addCashTip(amount: number) {
    if (!current) throw new Error("No hay turno abierto");
    setSessions(prev => prev.map(s => (s.id === current.id ? { ...s, ops: { ...s.ops, tips: { cashTips: (s.ops.tips?.cashTips || 0) + (amount || 0) } } } : s)));
  }

  function closeShift(signedBy?: string) {
    if (!current) throw new Error("No hay turno abierto");
    setSessions(prev => prev.map(s => (s.id === current.id ? { ...s, status: "CLOSED", close: { closedAt: Date.now(), signedBy } } : s)));
  }

  function listSessions() {
    return sessions;
  }

  const value: CashupContextValue = {
    current,
    openShift,
    addSale,
    addExpense,
    withdrawCash,
    addCashTip,
    closeShift,
    listSessions,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export function useCashup() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useCashup debe usarse dentro de <CashupProvider>");
  return v;
}
