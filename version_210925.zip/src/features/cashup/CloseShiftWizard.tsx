import React, { useMemo, useState } from "react";
import { useCashup } from "./cashupContext";
import { clp, toInt } from "@/utils/currency";

const CloseShiftWizard: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { current, closeShift } = useCashup();
  const [signedBy, setSignedBy] = useState(current?.open.cashierName || "");
  const [countedCash, setCountedCash] = useState("");

  const expectedCash = useMemo(() => {
    if (!current) return 0;
    const by = current.ops.salesRuntime.byMethod || {};
    const efectivo = by.EFECTIVO_SISTEMA || 0;
    const gastos = (current.ops.expenses || []).reduce((acc: number, e: { amount?: number }) => acc + (e?.amount ?? 0), 0);
    const retiros = current.ops.withdrawals || 0;
    const tips = current.ops.tips?.cashTips || 0;
    return (current.open.openingFloat || 0) + efectivo - gastos - retiros + tips;
  }, [current]);

  const diff = toInt(countedCash) - expectedCash;

  const doClose = () => {
    try {
      closeShift(signedBy || current?.open.cashierName);
      alert("Turno cerrado");
      onClose();
    } catch (e: any) {
      alert(e?.message || "No se pudo cerrar");
    }
  };

  return (
    <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-4 w-[420px] border">
        <h3 className="font-bold mb-2">Cerrar turno</h3>
        <div className="space-y-3 text-sm">
          <div className="flex justify-between"><span>Efectivo esperado</span><b>{clp(expectedCash)}</b></div>
          <input className="border rounded w-full px-2 py-1" placeholder="Efectivo contado $" value={countedCash} onChange={(e) => setCountedCash(e.target.value)} inputMode="numeric" />
          <div className="flex justify-between"><span>Diferencia</span><b className={diff === 0 ? "text-gray-700" : diff > 0 ? "text-emerald-700" : "text-red-700"}>{clp(diff)}</b></div>
          <input className="border rounded w-full px-2 py-1" placeholder="Responsable firma" value={signedBy} onChange={(e) => setSignedBy(e.target.value)} />
          <div className="flex justify-end gap-2">
            <button className="px-3 py-1 rounded border" onClick={onClose}>Cancelar</button>
            <button className="px-3 py-1 rounded bg-rose-600 text-white" onClick={doClose}>Cerrar turno</button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default CloseShiftWizard;
