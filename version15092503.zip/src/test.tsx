export const TestTailwind = () => (
  <div className="bg-red-500 text-white p-4 rounded-lg">
    ✅ Tailwind CSS v3 funcionando correctamente
  </div>
);