// src/components/cashier/PayPanel.tsx
import React, { useEffect, useMemo, useState } from "react";
import {
  CreditCard,
  DollarSign,
  Building2,
  CheckCircle2,
  AlertTriangle,
  Receipt,
} from "lucide-react";
import { useCashup } from "@/features/cashup/cashupContext";

type PaymentMethod = "efectivo" | "debito" | "credito" | "transferencia" | "mp";

type Props = {
  total: number;
  customerData: {
    name?: string;
    phone?: string;
    rut?: string;
    paymentMethod: PaymentMethod;
    mpChannel?: "delivery" | "local";
  };
  onChangeCustomerData: (d: Partial<Props["customerData"]>) => void;
  isPaying: boolean;
  onBackToCart: () => void;
  onConfirmPay: () => void;
  orderMeta?: any;
};

/* ===== Utils CL ===== */
const toNumber = (s: string | number) =>
  typeof s === "number" ? s : Number(String(s).replace(/[^\d]/g, "")) || 0;

const fmtCLP = (n: number) =>
  new Intl.NumberFormat("es-CL").format(Math.round(n || 0));

const fmtInputCLP = (s: string) => {
  const n = toNumber(s);
  return n ? n.toLocaleString("es-CL") : "";
};

/** RUT helpers */
function cleanRut(r: string) {
  return (r || "").toUpperCase().replace(/[.\s]/g, "").replace(/-+/g, "-");
}
function splitRut(r: string): [string, string] {
  const c = cleanRut(r).replace(/[^0-9K\-]/g, "");
  const [b, dv] = c.includes("-") ? c.split("-") : [c.slice(0, -1), c.slice(-1)];
  return [b || "", dv || ""];
}
function computeDv(body: string) {
  let sum = 0,
    mul = 2;
  for (let i = body.length - 1; i >= 0; i--) {
    sum += parseInt(body[i], 10) * mul;
    mul = mul === 7 ? 2 : mul + 1;
  }
  const res = 11 - (sum % 11);
  if (res === 11) return "0";
  if (res === 10) return "K";
  return String(res);
}
export function validateRut(rut: string) {
  const [body, dv] = splitRut(rut);
  if (!body || !dv) return false;
  return computeDv(body) === dv;
}
export function formatRut(rut: string) {
  const [body, dv] = splitRut(rut);
  if (!body) return "";
  const rev = body.split("").reverse().join("");
  const chunks = rev.match(/.{1,3}/g) || [];
  const withDots = chunks
    .map((c) => c.split("").reverse().join(""))
    .reverse()
    .join(".");
  return dv ? `${withDots}-${dv}` : withDots;
}

/* ===== Tip Modal (simple) ===== */
const TipModal: React.FC<{
  open: boolean;
  suggested: number;
  value: string;
  onChange: (v: string) => void;
  onAccept: () => void;
  onCancel: () => void;
}> = ({ open, suggested, value, onChange, onAccept, onCancel }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onCancel} />
      <div className="relative bg-white w-[92%] max-w-md rounded-xl shadow-xl p-5 border">
        <div className="text-lg font-semibold mb-1">¿Agregar propina?</div>
        <p className="text-sm text-gray-600 mb-3">
          Sugerimos el <b>10%</b> por un total de <b>${fmtCLP(suggested)}</b>.
          Puedes cambiarlo o dejarlo en <b>$0</b>.
        </p>
        <div className="grid grid-cols-2 gap-2 mb-3">
          <button
            className="btn-light"
            onClick={() => onChange(fmtInputCLP(String(suggested)))}
          >
            Usar 10% (${fmtCLP(suggested)})
          </button>
          <button className="btn-light" onClick={() => onChange("0")}>
            Sin propina
          </button>
        </div>
        <label className="text-sm text-gray-700">Propina ($)</label>
        <input
          className="input mt-1"
          placeholder="$"
          inputMode="numeric"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onBlur={(e) => onChange(fmtInputCLP(e.target.value))}
        />
        <div className="mt-4 flex justify-end gap-2">
          <button className="btn-light" onClick={onCancel}>
            Cancelar
          </button>
          <button className="btn-primary" onClick={onAccept}>
            Aceptar
          </button>
        </div>
      </div>
    </div>
  );
};

/* ===== Component ===== */
const PayPanel: React.FC<Props> = ({
  total,
  customerData,
  onChangeCustomerData,
  isPaying,
  onBackToCart,
  onConfirmPay,
}) => {
  // tolerante a contextos sin tipado exacto
  const cash = useCashup() as any;
  const current = cash?.current;

  const supportsRegisterSale = typeof cash?.registerSale === "function";
  const supportsFiscalDoc = typeof cash?.registerFiscalDoc === "function";

  // posibles APIs de propina
  const supportsAddCashTip = typeof cash?.addCashTip === "function";
  const supportsRegisterTip = typeof cash?.registerTip === "function";

  const [method, setMethod] = useState<PaymentMethod>(
    customerData.paymentMethod || "debito"
  );
  const [cashInStr, setCashInStr] = useState<string>("");
  const [emitBoleta, setEmitBoleta] = useState<boolean>(false);
  const [rutInput, setRutInput] = useState<string>(customerData.rut || "");
  const [mpChannel, setMpChannel] = useState<"delivery" | "local" | undefined>(
    customerData.mpChannel
  );
  const [refCode, setRefCode] = useState<string>(""); // transferencia / MP

  // Propina
  const grand = Math.round(total);
  const suggestedTip = Math.round(Math.ceil((grand * 0.1) / 100) * 100); // 10% redondeado a 100
  const [tipStr, setTipStr] = useState<string>(""); // string formateable
  const tipAmount = useMemo(() => toNumber(tipStr), [tipStr]);
  const [askTip, setAskTip] = useState(false);

  // cuando se cambia a EFECTIVO, sugerir propina si aún no preguntamos
  useEffect(() => {
    if (method === "efectivo" && !tipStr) {
      setAskTip(true);
    } else if (method !== "efectivo") {
      // propina solo en efectivo para el arqueo
      setTipStr("");
      setAskTip(false);
    }
  }, [method]); // eslint-disable-line

  // sincroniza con el parent sin perder tus props
  useEffect(() => {
    onChangeCustomerData({ paymentMethod: method });
  }, [method, onChangeCustomerData]);

  useEffect(() => {
    onChangeCustomerData({ rut: rutInput });
  }, [rutInput, onChangeCustomerData]);

  useEffect(() => {
    onChangeCustomerData({ mpChannel });
  }, [mpChannel, onChangeCustomerData]);

  const amountDue = useMemo(
    () => (method === "efectivo" ? grand + tipAmount : grand),
    [grand, tipAmount, method]
  );
  const cashIn = useMemo(() => toNumber(cashInStr), [cashInStr]);
  const change = Math.max(0, cashIn - amountDue);

  const canConfirm = useMemo(() => {
    if (!current) return false; // turno abierto obligatorio
    if (amountDue <= 0) return false;
    if (isPaying) return false;
    if (method === "efectivo") {
      if (cashIn < amountDue) return false; // no mixtos
    }
    if (emitBoleta && rutInput.trim().length > 0 && !validateRut(rutInput))
      return false;
    return true;
  }, [current, amountDue, isPaying, method, cashIn, emitBoleta, rutInput]);

  const saleMethodMap: Record<PaymentMethod, string> = {
    efectivo: "EFECTIVO_SISTEMA",
    debito: "DEBITO_SISTEMA",
    credito: "CREDITO_SISTEMA",
    transferencia: "TRANSFERENCIA",
    mp: "MERCADO_PAGO",
  };

  // Compatibilidad de firmas para registrar venta
  const safeRegisterSale = async (
    methodKey: string,
    amount: number,
    meta?: any
  ) => {
    if (!supportsRegisterSale) return;
    try {
      // firma objeto
      await cash.registerSale({ amount, method: methodKey, meta });
    } catch {
      try {
        // firma posicional
        await cash.registerSale(methodKey, amount, meta);
      } catch (e) {
        console.warn("[PayPanel] registerSale falló en ambas firmas", e);
      }
    }
  };

  // Registrar propina en efectivo (si el contexto lo soporta)
  const safeRegisterTip = async (amount: number, meta?: any) => {
    if (amount <= 0) return;
    try {
      if (supportsAddCashTip) {
        await cash.addCashTip(amount, meta);
        return;
      }
    } catch {}
    try {
      if (supportsRegisterTip) {
        // intentamos firma objeto
        await cash.registerTip({ amount, method: "CASH", meta });
        return;
      }
    } catch (e) {
      console.warn("[PayPanel] registerTip/addCashTip no disponibles", e);
    }
  };

  // Compatibilidad para registro fiscal (e-boleta)
  const safeRegisterFiscal = async (amount: number, rut?: string) => {
    if (!supportsFiscalDoc) return;
    const payload = {
      docType: "EBOLETA",
      amount,
      rut: rut || undefined,
      items: 1,
    };
    try {
      // firma objeto
      await cash.registerFiscalDoc(payload);
    } catch {
      try {
        // firma posicional simple: (amount, items)
        await cash.registerFiscalDoc(amount, 1);
      } catch (e) {
        console.warn("[PayPanel] registerFiscalDoc falló en ambas firmas", e);
      }
    }
  };

  const doConfirm = async () => {
    // 1) Impacta el Arqueo (venta)
    await safeRegisterSale(saleMethodMap[method], grand, {
      channel: method === "mp" ? mpChannel || "local" : undefined,
      refCode: refCode || undefined,
      cashIn: method === "efectivo" ? cashIn : undefined,
      change: method === "efectivo" ? change : undefined,
    });

    // 2) Propina efectivo (si corresponde)
    if (method === "efectivo" && tipAmount > 0) {
      await safeRegisterTip(tipAmount, { reason: "PROPINA", orderTotal: grand });
    }

    // 3) E-boleta opcional
    if (emitBoleta) {
      const rutFormatted = formatRut(rutInput);
      await safeRegisterFiscal(grand, rutFormatted);
    }

    // 4) Crea la orden
    onConfirmPay();
  };

  // quick cash helpers
  const setExacto = () => setCashInStr(fmtInputCLP(String(amountDue)));
  const addInc = (inc: number) =>
    setCashInStr(fmtInputCLP(String(toNumber(cashInStr) + inc)));
  const redondearMil = () => {
    const n = Math.ceil(amountDue / 1000) * 1000;
    setCashInStr(fmtInputCLP(String(n)));
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      {/* Tip modal */}
      <TipModal
        open={askTip}
        suggested={suggestedTip}
        value={tipStr}
        onChange={setTipStr}
        onAccept={() => setAskTip(false)}
        onCancel={() => {
          setTipStr("");
          setAskTip(false);
        }}
      />

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <CreditCard size={18} className="text-rose-600" />
          <h3 className="font-semibold text-gray-900">Pagar Pedido</h3>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-600">Total a pagar</div>
          <div className="text-2xl font-extrabold text-rose-600">
            ${fmtCLP(grand)}
          </div>
          {method === "efectivo" && tipAmount > 0 && (
            <div className="text-xs text-gray-600">
              + Propina: ${fmtCLP(tipAmount)} ={" "}
              <b>${fmtCLP(amountDue)}</b>
            </div>
          )}
        </div>
      </div>

      {!current && (
        <div className="mb-4 p-3 rounded border border-yellow-200 bg-yellow-50 text-sm text-yellow-800">
          Debes <b>abrir la caja</b> desde el panel superior para poder cobrar.
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-6">
        {/* Método de pago */}
        <div className="md:col-span-1">
          <div className="text-sm font-medium text-gray-700 mb-2">Método</div>
          <div className="grid grid-cols-2 gap-2">
            <button
              className={`px-3 py-2 border rounded-lg text-sm ${
                method === "efectivo"
                  ? "border-rose-500 text-rose-600 bg-rose-50"
                  : "hover:bg-gray-50"
              }`}
              onClick={() => setMethod("efectivo")}
            >
              <DollarSign className="inline mr-1" size={14} /> Efectivo
            </button>
            <button
              className={`px-3 py-2 border rounded-lg text-sm ${
                method === "debito"
                  ? "border-rose-500 text-rose-600 bg-rose-50"
                  : "hover:bg-gray-50"
              }`}
              onClick={() => setMethod("debito")}
            >
              <CreditCard className="inline mr-1" size={14} /> Débito
            </button>
            <button
              className={`px-3 py-2 border rounded-lg text-sm ${
                method === "credito"
                  ? "border-rose-500 text-rose-600 bg-rose-50"
                  : "hover:bg-gray-50"
              }`}
              onClick={() => setMethod("credito")}
            >
              <CreditCard className="inline mr-1" size={14} /> Crédito
            </button>
            <button
              className={`px-3 py-2 border rounded-lg text-sm ${
                method === "transferencia"
                  ? "border-rose-500 text-rose-600 bg-rose-50"
                  : "hover:bg-gray-50"
              }`}
              onClick={() => setMethod("transferencia")}
            >
              <Building2 className="inline mr-1" size={14} /> Transferencia
            </button>
            <button
              className={`px-3 py-2 border rounded-lg text-sm col-span-2 ${
                method === "mp"
                  ? "border-rose-500 text-rose-600 bg-rose-50"
                  : "hover:bg-gray-50"
              }`}
              onClick={() => setMethod("mp")}
            >
              <CreditCard className="inline mr-1" size={14} /> Mercado Pago
            </button>
          </div>

          {/* Banda de propina rápida */}
          {method === "efectivo" && !askTip && (
            <div className="mt-3 p-2 rounded border border-blue-200 bg-blue-50 text-xs text-blue-800">
              ¿Deseas agregar propina?
              <div className="mt-2 flex flex-wrap gap-2">
                <button
                  className="badge"
                  onClick={() => setTipStr(fmtInputCLP(String(suggestedTip)))}
                >
                  +10% (${fmtCLP(suggestedTip)})
                </button>
                <button className="badge" onClick={() => setAskTip(true)}>
                  Otra cantidad
                </button>
                {tipAmount > 0 && (
                  <button className="badge" onClick={() => setTipStr("")}>
                    Quitar propina
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Detalles / efectivo y referencias */}
        <div className="md:col-span-1">
          <div className="text-sm font-medium text-gray-700 mb-2">Detalles</div>

          {method === "efectivo" ? (
            <>
              <label className="text-sm text-gray-700">¿Con cuánto paga?</label>
              <input
                className="input mt-1"
                placeholder="$"
                inputMode="numeric"
                value={cashInStr}
                onChange={(e) => setCashInStr(e.target.value)}
                onBlur={(e) => setCashInStr(fmtInputCLP(e.target.value))}
              />
              <div className="mt-2 flex flex-wrap gap-2">
                <button className="badge" onClick={setExacto}>
                  Exacto
                </button>
                <button className="badge" onClick={() => addInc(1000)}>
                  +$1.000
                </button>
                <button className="badge" onClick={() => addInc(2000)}>
                  +$2.000
                </button>
                <button className="badge" onClick={() => addInc(5000)}>
                  +$5.000
                </button>
                <button className="badge" onClick={() => addInc(10000)}>
                  +$10.000
                </button>
                <button className="badge" onClick={redondearMil}>
                  Redondear a mil
                </button>
              </div>

              <div className="mt-2 text-sm">
                <div className="text-gray-600">
                  {tipAmount > 0 ? (
                    <>
                      Total: <b>${fmtCLP(grand)}</b> + Propina:{" "}
                      <b>${fmtCLP(tipAmount)}</b> ={" "}
                      <b>${fmtCLP(amountDue)}</b>
                    </>
                  ) : (
                    <>
                      Total: <b>${fmtCLP(grand)}</b>
                    </>
                  )}
                </div>
                <div
                  className={`${
                    cashIn >= amountDue ? "text-green-700" : "text-red-700"
                  }`}
                >
                  {cashIn >= amountDue ? "Vuelto" : "Falta"}:{" "}
                  <b>${fmtCLP(Math.abs(cashIn - amountDue))}</b>
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="text-sm text-gray-600 mb-2">
                El total se cobrará íntegro con <b>{method.toUpperCase()}</b>.
                No se permiten pagos mixtos.
              </div>
              {(method === "mp" || method === "transferencia") && (
                <>
                  <label className="text-sm text-gray-700">
                    Referencia (opcional)
                  </label>
                  <input
                    className="input mt-1"
                    placeholder="ID de transacción, últimos 4, etc."
                    value={refCode}
                    onChange={(e) => setRefCode(e.target.value)}
                  />
                </>
              )}
            </>
          )}
        </div>

        {/* E-Boleta */}
        <div className="md:col-span-1">
          <div className="text-sm font-medium text-gray-700 mb-2">E-Boleta</div>
          <label className="inline-flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={emitBoleta}
              onChange={(e) => setEmitBoleta(e.target.checked)}
            />
            Emitir e-boleta
            <Receipt size={14} className="text-gray-500" />
          </label>

          <div className="mt-2">
            <label className="text-sm text-gray-700">RUT (opcional)</label>
            <input
              className={`input mt-1 ${
                emitBoleta && rutInput && !validateRut(rutInput)
                  ? "border-red-400"
                  : ""
              }`}
              placeholder="12.345.678-5"
              value={rutInput}
              onChange={(e) => setRutInput(e.target.value)}
              onBlur={() => setRutInput((v) => formatRut(v))}
              disabled={!emitBoleta}
            />
            {emitBoleta && rutInput && !validateRut(rutInput) && (
              <div className="text-xs text-red-600 mt-1">RUT inválido</div>
            )}
            {!supportsFiscalDoc && emitBoleta && (
              <div className="mt-2 p-2 rounded bg-yellow-50 border border-yellow-200 text-xs text-yellow-800 flex items-center gap-2">
                <AlertTriangle size={14} /> Tu <code>cashupContext</code> no
                implementa <b>registerFiscalDoc</b>. Se creará el pedido igual,
                pero no quedará el registro fiscal.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Acciones */}
      <div className="mt-6 flex items-center justify-between">
        <button
          onClick={onBackToCart}
          className="px-4 py-2 border rounded-lg hover:bg-gray-50"
        >
          Volver
        </button>
        <button
          disabled={!canConfirm}
          onClick={doConfirm}
          className={`px-4 py-2 rounded-lg text-white inline-flex items-center gap-2 ${
            canConfirm ? "bg-rose-600 hover:bg-rose-700" : "bg-gray-300"
          }`}
          title={!current ? "Abre la caja para poder cobrar" : undefined}
        >
          <CheckCircle2 size={16} /> Confirmar y Cobrar
        </button>
      </div>
    </div>
  );
};

export default PayPanel;
