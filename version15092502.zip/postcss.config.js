// ✅ Sintaxis ES Module
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}